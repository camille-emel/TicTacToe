package FOUYTOUT;

import java.util.Scanner;

public class UserInteraction {
    public UserInteraction() {

    }

}
