package FOUYTOUT;

public class HumanPlayer extends Player {

    public HumanPlayer() {

    }

    @Override
    public void makeMove() {
        TicTacToe.getMoveFromPlayer();
    }
}
