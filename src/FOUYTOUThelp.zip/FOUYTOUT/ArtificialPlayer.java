package FOUYTOUT;

public class ArtificialPlayer extends Player {

    public ArtificialPlayer() {

    }
    @Override
    public void makeMove(Cell[][] board) {

    }

}
